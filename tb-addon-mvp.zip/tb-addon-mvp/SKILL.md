---
name: tb-addon-mvp
description: Maakt een MVP-pakket voor een Track & Back add-on, zodat een nog-niet-gebouwde add-on visueel te valideren is voordat er code geschreven wordt. Levert een mappenstructuur op met realistische synthetische e-mails (.eml RFC 5322) als test-input én één self-contained app-view HTML-bestand in TB-merkstijl (Inter, primair blauw #2661B0, accent oranje #FF8500, licht thema) dat toont wat de TB-app de gebruiker zou laten zien als deze e-mails binnenkomen. Use this skill whenever the user types /tb-addon-mvp followed by een add-on concept, or asks om "synthetische mails", "test-mails voor een add-on", "een mockup van wat de app zou tonen", "MVP voor add-on X", or wants to validate een TB add-on (retour-bewaking, reis-companion, abonnement-tracker, garantie-bewaking, andere add-ons uit cluster trackandback-product) before any code is written. Make sure to use this skill voordat er bouw-issues worden aangemaakt voor een nieuwe add-on, especially wanneer het add-on idee nog niet is afgepeld of wanneer Gertjan eerst wil zien hoe het concept eruit zou zien.
---

# tb-addon-mvp

Een skill voor Gertjan Antonisse die een nog-niet-gebouwde Track & Back add-on visueel beoordeelbaar maakt door synthetische e-mails én een TB-stijl app-view mockup te genereren. Doel: vóór dat er een lead-issue wordt aangemaakt of code wordt geschreven, kan Gertjan, Timo of Octa zien wat de add-on doet, welke e-mails hij verwerkt, en hoe het resultaat eruitziet in de app.

De skill is een MVP-tool, geen ontwerp-tool. De output is uitleg-materiaal voor een nog te nemen beslissing, niet een specificatie die direct naar dev gaat.

## Wanneer deze skill triggert

- Gebruiker typt `/tb-addon-mvp` gevolgd door een add-on concept
- Gebruiker vraagt om synthetische e-mails, test-mails, of een MVP voor een TB add-on
- Gebruiker wil zien hoe een add-on uit het cluster trackandback-product (retour, abonnement, garantie, reis-companion, opzegging, andere) eruit zou zien als hij werkte
- Gebruiker verkent een nieuwe add-on-richting en wil eerst zien voordat er een lead-issue komt

De skill triggert **niet** bij vragen over bestaande, gebouwde features. Daarvoor is `/tb-ux-spec` de juiste skill.

## Werkprincipes

1. **Merkprincipes leidend.** Loslaten boven controle, afronding boven informatie, rust boven engagement, helderheid boven complexiteit. De app-view mockup moet voelen als afronding, niet als dashboard. Als de mockup eindigt met een lijst die monitoring vraagt van de gebruiker, klopt iets niet.
2. **E-mails zijn de bron, niet de feature.** TB werkt vanuit echte e-mailruis. De synthetische mails moeten plausibel klinken: echte afzenders, plausibele headers, transactionele teksten, soms marketing-ruis ertussen. Niet vier perfect gestructureerde JSON-achtige e-mails.
3. **Eén scenario, één gebruiker.** Eén add-on per run, gekoppeld aan één concrete persoon met één concrete situatie. Geen abstracte demo-set.
4. **Zelfstandig leesbaar.** De output-folder moet voor Timo of Octa direct te openen en te begrijpen zijn, zonder dat Gertjan hoeft uit te leggen wat erin zit.

## Verkenningsritueel

Vóór generatie altijd kort verkennen (zie `~/.claude/CLAUDE.md`). Drie checks:

1. **Bestaat de add-on al ergens als capture, issue of mockup?**
   - `gh issue list --repo GertjanAntonisse/antonisse-richting-os --search "<trefwoord> kans"`
   - `gh issue list --repo GertjanAntonisse/trackandback-product --search "<trefwoord>"`
   - `ls ~/ai-projects/trackandback/addon-mvps/` om dubbele MVP-runs te voorkomen
2. **Past de add-on bij een hoofd- of zijstroom?**
   Zie product-issues #50, #51, #52 (hoofdstromen) en #53, #54, #55 (add-on stromen). Benoem aan welke stroom de add-on hangt.
3. **Welke aannames moeten getoetst worden?**
   Maak expliciet welke gedragsaannames in de mockup zitten. Niet alles vragen, wel benoemen.

Output van verkenning: drie korte kopjes in de prompt voor Gertjan, vóór generatie begint. Bij overlap met bestaand werk: voorstellen om verder te bouwen op die capture in plaats van een nieuwe MVP-folder aan te maken.

## Verplichte werkstappen

### Stap 1: Concept scherp krijgen

Wat is de add-on in één zin? Welke afronding biedt hij aan welke gebruiker, op welk moment? Vraag bij vaagheid één gerichte vraag, ga niet door op een onhelder concept.

Sluit de concept-zin altijd af in dezelfde structuur:
> "[Add-on naam] neemt voor [gebruikerstype] de [specifieke mentale belasting] weg rond [moment of situatie], door uit binnenkomende e-mails alleen [specifieke afronding] te tonen."

Voorbeeld: "Retour-companion neemt voor online-shoppers de retour-deadline-bewaking weg rond aankopen met retourrecht, door uit binnenkomende order- en verzendmails alleen het uiterste retourmoment en de retourstap te tonen."

### Stap 2: Scenario uittekenen

Bepaal:
- **Persoon**: naam, leeftijd indien relevant, mailadres (gebruik een TB-alias, bijvoorbeeld `lisa@trackandback.email` of `tom.aankopen@trackandback.email`)
- **Tijdlijn**: over welke periode arriveren de mails (uren, dagen, weken)
- **Context**: wat deed de persoon, welke afronding wil hij eigenlijk
- **Eindmoment**: wanneer "klopt het", wanneer kan de app afsluiten

### Stap 3: Mailset bepalen

Welke e-mails komen binnen in dit scenario? Maak een lijst van 4–10 mails, een mix van:
- Transactionele bevestigingen (orderbevestiging, boeking, factuur)
- Statusupdates (verzonden, vertraagd, bezorgd, gewijzigd)
- Reminders of waarschuwingen (deadline, actie vereist)
- Marketing-ruis tussendoor (één of twee), om realisme te geven dat TB juist die uitfiltert
- Eventueel een "fout-positief" of edge-case (dubbele bevestiging, taalwissel, ongebruikelijk format)

Voor elke mail: afzender, onderwerp, korte beschrijving van de inhoud, en welk element ervan in de app-view terechtkomt. Toon deze tabel aan Gertjan voordat je gaat genereren, zodat hij kan corrigeren.

### Stap 4: Synthetische e-mails genereren

Per mail één bestand in `emails/`, genummerd in chronologische volgorde: `01-orderbevestiging-bolcom.eml`, `02-verzendupdate-postnl.eml`, etc.

Volg `references/eml-conventions.md` voor structuur en realisme.

### Stap 5: App-view mockup genereren

Eén self-contained `app-view.html` in TB-stijl. Inline CSS, geen externe afhankelijkheden behalve Google Fonts voor Inter.

Volg `references/app-view-template.html` als startpunt en `references/brand-tokens.md` voor de tokens. De mockup toont wat de app aan de gebruiker laat zien op het moment dat de afronding kan worden afgeleid uit de mailset.

**Belangrijk voor de stijl:**
- Licht thema (achtergrond `#F8FAFC` / `#FFFFFF`), niet donker
- Mobiel-first, max-width `420px` voor de hoofdcontainer (TB is app-first)
- Eén scherm, geen tabs, geen navigatie
- Eén primaire actie maximaal (Secondary 500 oranje knop)
- Eén afsluitende rust-formulering onderaan (bijvoorbeeld "Track & Back houdt de rest in de gaten." of "Klaar. Je hoeft niets meer te doen.")
- Niet meer dan 3 informatie-niveaus diep

### Stap 5b: Verdieping genereren (lichte versie)

Naast het voorbeeldscherm hoort een **verdieping**: de achtergrond waarmee Gertjan of Timo onderbouwd kan beslissen of de add-on nu gemaakt wordt, een nice-to-have is, of iets voor later. De verdieping wordt getoond als tweede tab in `mvp.html`, naast het voorbeeldscherm.

De verdieping heeft vier onderdelen plus een aanbeveling:

1. **Visie-toets.** Toets de add-on aan de TB-merkprincipes (loslaten boven controle, afronding boven informatie, rust boven engagement, helderheid, vertrouwen, en de productrichtlijn: geen monitoring/dashboard). Geef per principe een eerlijk oordeel, ook als de uitkomst "past niet" of "past, mits" is. Dit is de ingebouwde visie-waarborg. Veelvoorkomend risico bij overzicht-achtige add-ons: het wordt een dashboard, en dat is TB expliciet niet.
2. **Trends en wetgeving** die het idee raken. Bron: de stroom-issues (wetgeving zoals EU261, Wet Van Dam, AVG), Signal Digests en de visie-repo.
3. **De markt.** Wie doet dit al, wat kunnen wij beter of anders. Benoem bekende spelers.
4. **Het geld.** Verdienmodel-hook en globale waarde-inschatting. Bron: #57, #83, #85.
5. **Aanbeveling:** nu, nice-to-have of later, met één regel onderbouwing en de expliciete noot dat het een voorstel is, geen besluit (de keuze is aan Timo).

**Verwijs naar echte issues, met hun status.** Onderbouw elk onderdeel met concrete issues uit de visie- en product-repo's (bijvoorbeeld `trackandback-visie`, `trackandback-product`), als klikbare links, met een status-badge: `geverifieerd` (label `verified`), `besloten` (`status:besloten`), `onderzoek` (`type:onderzoek` / `status:verkennend`), of `aanname / extern` als het nog niet in een issue is onderbouwd. Dat laatste eerlijk markeren is net zo belangrijk als het bevestigde: het maakt zichtbaar wat nog getoetst moet worden. De visie-repo heeft een verificatie-systeem voor voorspellingen (L2-/L3-codes met `verified`), gebruik dat als ankers. Haal de actuele status op met `gh issue list`/`gh issue view`, verzin geen status.

**Lichte versie (huidige stand).** De verdieping wordt nu handmatig samengesteld uit de genoemde bronnen, niet automatisch opgehaald. Markeer dat in de tab met een "lichte versie, ter bespreking"-badge. Het automatisch ophalen en een vast format zijn vervolgwerk, zie Richting #275.

`mvp.html` is een dun omhulsel: een tabbalk in TB-stijl, tab 1 toont `app-view.html` in een iframe (in een telefoon-frame), tab 2 bevat de verdieping inline. Houd de verdieping leesbaar en feitelijk, met bronvermelding per onderdeel.

### Stap 6: README schrijven

Korte `README.md` in de root van de add-on folder met:
- Add-on concept-zin uit stap 1
- Persoon en scenario uit stap 2
- Tijdlijn van de mails (samenvattende lijst)
- Aannames die in de mockup zitten en getoetst moeten worden
- Open vragen voor Gertjan, Timo of Octa
- Verwijzingen naar relevante product-issues (#50-55 stromen, of specifieke add-on issues)

### Stap 7: Opleveren

1. Plaats alles in `~/ai-projects/trackandback/addon-mvps/{slug}/` waar `{slug}` een korte kebab-case naam is (`retour-companion`, `reis-overzicht`, `abonnement-tracker`)
2. Open de gegenereerde `mvp.html` in een browser ter visuele controle (bash: `open <path>`). Dat toont beide tabs, het voorbeeldscherm en de verdieping
3. Meld in chat: pad naar folder, één-zin samenvatting van de mockup, en de open vragen die in de README staan
4. Vraag of er een Capture in Richting moet komen met type `TB-kans` of `experiment` die naar deze folder verwijst

## Output-structuur

```
~/ai-projects/trackandback/addon-mvps/{slug}/
├── README.md
├── emails/
│   ├── 01-{korte-beschrijving}.eml
│   ├── 02-{korte-beschrijving}.eml
│   └── ...
├── app-view.html        (de maquette: het voorbeeldscherm)
└── mvp.html             (omhulsel met twee tabs: Voorbeeldscherm + Verdieping)
```

Geen extra subfolders, geen losse CSS-bestanden. De `app-view.html` is altijd één self-contained HTML zonder JS. De `mvp.html` is een dun omhulsel dat `app-view.html` in een iframe toont (tab 1) en de verdieping inline (tab 2), met alleen een klein stukje tab-JS.

## Brand-stijl

Track & Back gebruikt Inter als primaire typeface, een blauw primair palet en oranje als enige accent. Licht thema, geen donkere variant. Zie `references/brand-tokens.md` voor de complete token-set en hoe ze in CSS te inlijven.

Belangrijke regels die níet onderhandelbaar zijn:
- Inter via Google Fonts (`https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap`)
- Achtergrond `#F8FAFC` of `#FFFFFF`, nooit een donkere variant
- Primair blauw `#2661B0` voor headers en links, `#FF8500` oranje uitsluitend voor de primaire actie of een enkel accent
- Geen em-dash in Nederlandse tekst (Richting-regel), gebruik komma of dubbele punt
- Eén CTA-knop maximaal op het scherm, in radius `12px`

## E-mail-conventies

Zie `references/eml-conventions.md` voor RFC 5322 structuur, realistische afzender-domeinen, MIME multipart, en variatie in talen en tone-of-voice per afzender.

## Voorbeelden van geschikte add-ons

Zie `references/example-addons.md` voor 4 uitgewerkte concept-zinnen die de skill kan gebruiken als calibratie wanneer Gertjan kort iets noemt zoals "doe iets met garantie" of "verken een travel-add-on".

## Wat NIET in deze skill

- Geen specs voor implementatie (geen API-velden, geen database-schema's, geen technische architectuur)
- Geen donker thema, geen alternatieve typografie, geen experimentele kleuren
- Geen demo-data voor screens die al gebouwd zijn (gebruik `/tb-ux-spec` of werk direct in de lead-repo)
- Geen aanmaken van GitHub-issues automatisch, alleen voorstellen via de stop-protocol Capture-vraag
- Geen meer dan één scherm in de app-view, een MVP is één moment van afronding

## Trigger-voorbeeld

```
/tb-addon-mvp Verken een retour-companion add-on. Persoon: Lisa, koopt vaak kleding online,
mist soms de 30-dagen retourtermijn. Mailset moet bevatten: orderbevestiging, verzendmail,
bezorgmail, en een ruis-mail. App-view toont één duidelijk retourmoment.
```

## Wat de gebruiker terugkrijgt

1. Een korte verkenningsuitkomst (3 kopjes), getoetst voordat er gegenereerd wordt
2. Een concept-zin in vaste structuur, ter goedkeuring
3. Een mailset-tabel, ter goedkeuring
4. Een folder onder `addon-mvps/` met README, e-mails, de app-view en `mvp.html` met twee tabs (voorbeeldscherm en verdieping)
5. Een open browser-tab met `mvp.html`, waarin het voorbeeldscherm en de verdieping naast elkaar staan
6. Een voorstel voor een Richting Capture of vervolgissue

Bij afwijking of feedback: één iteratie tegelijk, niet alles tegelijk hergenereren.
