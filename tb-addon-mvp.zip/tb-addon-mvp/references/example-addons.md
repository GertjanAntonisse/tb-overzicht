# Voorbeeld-add-ons voor TB

Calibratie-set met vier add-on concept-zinnen, mailsets en app-view kern. De skill kan deze gebruiken als referentie wanneer Gertjan een kort idee noemt zoals "doe iets met retour" of "verken garantie".

Aan elke add-on hangt een hoofd- of zijstroom uit `trackandback-product`:
- Hoofdstroom 1 — Aankopen en boekingen (#50)
- Hoofdstroom 2 — Lopende verplichtingen (#51)
- Hoofdstroom 3 — Registraties met staart (#52)
- Add-on stroom 1 — Aankopen en boekingen (#53)
- Add-on stroom 2 — Lopende verplichtingen (#54)
- Add-on stroom 3 — Registraties met staart (#55)

## 1. Retour-companion

> Retour-companion neemt voor online-shoppers de retour-deadline-bewaking weg rond aankopen met retourrecht, door uit binnenkomende order- en verzendmails alleen het uiterste retourmoment en de retourstap te tonen.

- Stroom: add-on 1 (#53)
- Mailset: orderbevestiging shop, verzendmail bezorger, bezorgmail bezorger, ruis-nieuwsbrief, retour-reminder shop, eventueel een productpagina-promotie
- App-view kern: één card met "Bestelling X is bezorgd op datum Y", retourtermijn als visuele teller, primaire actie "Start retour" met deeplink naar retourportaal
- Afronding-zin: "Klaar. Track & Back herinnert je drie dagen voor de retourdeadline."

## 2. Reis-overzicht (KL-trip variant)

> Reis-overzicht neemt voor reizigers de samenvoeging van losse boekingen weg rond een specifieke reis, door uit binnenkomende vlucht-, hotel-, transfer- en immigratiemails één rustig reisscherm te tonen.

- Stroom: add-on 1 (#53) of nieuw spoor
- Mailset: heenvlucht-bevestiging, hotelbevestiging, retourvlucht-bevestiging, immigratie-reminder (waar relevant), transfer-bevestiging, eventueel een vliegmaatschappij-nieuwsbrief
- App-view kern: header met route en datums, één card met hotel, één card met vluchten heen en terug, kleine call-out met immigratie-actie, geen primaire CTA als alles klaar is
- Afronding-zin: "Alles staat klaar. Je hoeft niets meer voor te bereiden."
- Inspiratie: `/Users/gertjan/Downloads/kl-trip.html` (donker, andere stijl, maar zelfde informatie-architectuur)

## 3. Abonnement-tracker

> Abonnement-tracker neemt voor consumenten het overzicht van lopende verplichtingen weg rond hun maandelijkse afschrijvingen, door uit binnenkomende factuur- en welkomstmails per abonnement één rustig statuskaartje te tonen met opzeg-deadline en eerstvolgend bedrag.

- Stroom: hoofdstroom 2 (#51) en add-on 2 (#54)
- Mailset: welkomstmail nieuwe dienst, eerste factuur, prijsverhoging-aankondiging, herinneringsmail, eventueel een marketing-mail van de dienst zelf
- App-view kern: één scherm per abonnement of een lijstvariant met één geselecteerd abonnement actief, opzegtermijn als vetgedrukte deadline, primaire actie "Opzeggen via dienst" met deeplink
- Afronding-zin: "Je weet wat loopt. Track & Back signaleert wijzigingen."

## 4. Garantie-bewaking

> Garantie-bewaking neemt voor productkopers de garantietermijn-bewaking weg rond grotere aankopen, door uit binnenkomende factuur- en orderbevestigingsmails de garantieperiode af te leiden en alleen relevante actiestappen te tonen.

- Stroom: add-on 1 (#53)
- Mailset: orderbevestiging elektronicawinkel, factuur, verzendmail, ruis-nieuwsbrief, eventueel een service-uitbreiding aanbieding na 3 maanden
- App-view kern: productnaam, aankoopdatum, garantie-einddatum als zichtbare deadline, primaire actie "Bewaar bewijs" of "Meld defect" wanneer relevant
- Afronding-zin: "Je bewijs is veilig. Track & Back herinnert je twee weken voor het einde van de garantie."

## Patronen die in elke add-on terugkomen

1. **Tijdgrens** is meestal het belangrijkste gegeven: retourtermijn, vlucht, opzegtermijn, garantie-einde
2. **Eén primaire actie** maximaal: start retour, check-in, opzeggen, melding maken
3. **Ruis-mail erbij** maakt het realisme zichtbaar (TB filtert wat niet hoeft)
4. **Afronding-zin** maakt duidelijk dat de gebruiker niets meer hoeft
5. **Bronnenlijst onderaan** toont welke mails verwerkt zijn, zonder dat de gebruiker erin hoeft te klikken

## Wat de skill van deze lijst leert

- Vier voorbeelden, vier verschillende stromen, vier verschillende afrondingsmomenten
- Allemaal hebben ze één scherm, niet meerdere
- De mailset varieert in omvang (4 tot 6 mails) maar nooit minder dan 4 (anders is er geen "verwerking" zichtbaar) en nooit meer dan 8 (anders wordt het cognitief zwaar)
- De afronding-zin is altijd in twee delen: een claim ("klaar", "alles staat klaar", "je weet wat loopt") gevolgd door wat TB blijft doen
