# .eml conventies voor synthetische TB-mails

Doel: e-mails die voor een mens, een mailclient én een parser overtuigend echt voelen. Geen perfect-gestructureerde demo-mails, wel plausibele transactionele tekst met de gebruikelijke ruis.

## RFC 5322 minimum-structuur

Elke `.eml` heeft minstens:

```
From: "Naam Afzender" <transactional@afzender.nl>
To: "Lisa van Dijk" <lisa.kleding@trackandback.email>
Reply-To: no-reply@afzender.nl
Subject: =?utf-8?Q?Je_bestelling_is_onderweg?=
Date: Wed, 14 May 2026 09:32:14 +0200
Message-ID: <20260514-093214-abc123@afzender.nl>
MIME-Version: 1.0
Content-Type: multipart/alternative; boundary="----=_Part_1234"

------=_Part_1234
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: quoted-printable

Hi Lisa,

Je bestelling met ordernummer 105772634 is verzonden via PostNL...

------=_Part_1234
Content-Type: text/html; charset=UTF-8
Content-Transfer-Encoding: quoted-printable

<!DOCTYPE html>
<html><body style="font-family:Arial,sans-serif;...">
  <h1>Onderweg!</h1>
  ...
</body></html>

------=_Part_1234--
```

Iedere mail krijgt:
- `From` met realistische afzender-naam én transactional-domein
- `To` met TB-alias van de gebruiker
- `Subject` (UTF-8 quoted-printable als er accenten in zitten)
- `Date` in RFC 2822 formaat, met realistisch tijdstip (kantoor-uren voor NL-shops, vroege ochtend voor internationale)
- `Message-ID` (kort gegenereerd, geen `<example.com>` placeholders)
- Multipart-alternative met `text/plain` én `text/html`

## Realistische afzenders per categorie

| Categorie | Voorbeelden | Tone |
|---|---|---|
| NL webshops | bol.com, coolblue.nl, wehkamp.nl, hema.nl, albert.nl | hartelijk, jij-vorm, kort |
| NL fashion | wehkamp, zalando.nl, hm.com/nl, vanharen.nl | jij-vorm, productfocus |
| Bezorgers | postnl.nl, dhl.nl, dpd.nl, ups.com | feitelijk, status-updates |
| Reizen | klm.com, booking.com, airbnb.nl, ns.nl, transavia.com | formeel, info-dicht |
| Betaal | klarna.nl, ideal.nl, mollie.com | functioneel, factuur-stijl |
| Subscriptions | netflix.com, spotify.com, t-mobile.nl, kpn.com | maand-cyclus, factuur |
| Marketing-ruis | nieuwsbrief van shop X, "5 tips voor..." | verkooptaal, korter laten zijn |

Wissel talen waar passend: KLM/Booking in Engels, NL-shops in Nederlands.

## Inhoud-richtlijnen per mail

1. **Begroet de persoon bij voornaam** als de afzender een NL-shop is. Geen "Hi customer".
2. **Eén kerngegeven per mail** dat de parser nodig heeft: ordernummer, tracking-code, deadline, bedrag, datum. Verstop dit niet, maar laat het ook niet schreeuwen, het hoort gewoon in de tekst.
3. **Marketing-footer** voor shop-mails: "Volg ons op Instagram" etc. Eén paragraaf, twee zinnen.
4. **Unsubscribe-link** voor marketing-achtige mails.
5. **Geen lorem ipsum.** Echte zinnen, ook al zijn ze kort.
6. **Lengte:** 200–600 woorden voor transactionele mails, 80–200 voor marketing-ruis.

## Voorbeeld plain-text body (orderbevestiging Bol)

```
Hi Lisa,

Bedankt voor je bestelling bij bol.com. We hebben je bestelling ontvangen en gaan er meteen mee aan de slag.

Bestelnummer:    105772634
Geplaatst op:    14 mei 2026 om 09:31
Levering:        morgen (15 mei) tussen 11:00 en 14:00

Wat je hebt besteld:

  Levi's 501 Original Fit jeans, donkerblauw - maat 30/32
  Aantal: 1
  Prijs: € 89,99

  Champion crewneck sweater, grijs - maat M
  Aantal: 1
  Prijs: € 49,99

Verzendkosten:   gratis
Totaal:          € 139,98

Bezorgadres:
Lisa van Dijk
Singel 421
1012 WP Amsterdam

Retourtermijn: 30 dagen vanaf ontvangst.

Bekijk je bestelling: https://bol.com/orders/105772634

Volg ons op Instagram of TikTok voor de laatste deals.

Hartelijke groet,
bol.com klantenservice

---
bol.com b.v. — Papendorpseweg 100, 3528 BJ Utrecht
KvK 32107739 — Afmelden voor nieuwsbrieven
```

## Voorbeeld plain-text body (verzendupdate PostNL)

```
Beste Lisa,

Goed nieuws. Je pakket is onderweg.

Trackingcode:    3SKABA9876543210
Verzonden door:  bol.com
Geschatte bezorging: vrijdag 15 mei, tussen 11:00 en 14:00

Volg je pakket live: https://postnl.nl/tracking/3SKABA9876543210

Niet thuis? PostNL probeert een buur te bereiken of brengt je pakket later opnieuw langs. Je hoeft niets te doen.

Met vriendelijke groet,
PostNL
```

## Bestandsnaam-conventie

`{volgnummer}-{korte-beschrijving}-{afzender}.eml`

Voorbeelden:
- `01-orderbevestiging-bol.eml`
- `02-verzendupdate-postnl.eml`
- `03-bezorgd-postnl.eml`
- `04-nieuwsbrief-hema.eml` (de ruis-mail)
- `05-retour-reminder-bol.eml`

Tweecijferig volgnummer zodat alfabetisch sorteren overeenkomt met de tijdlijn.

## Wat NIET doen

- Geen `From: test@example.com` of `From: noreply@noreply.com`. Echte afzender-naam, echt domein.
- Geen perfect-spelende headers als de afzender dat in werkelijkheid ook niet heeft (Booking gebruikt soms ALL CAPS subjects, KLM gebruikt vaak `KLM Royal Dutch Airlines <Customer.Service@KLM.com>`).
- Geen JSON, geen markdown in de body. Echte HTML voor de html-part, echte plain text voor de plain-part.
- Geen "deze mail is fictief" disclaimer in de body. De .eml is een artefact, de README legt het uit.
- Geen ECHTE persoonlijke data (geen echte mailadressen van bekenden, geen echte adressen). Alles fictief maar plausibel.

## Optioneel: een HTML-rendering preview

Voor visuele controle kan in de README een link staan naar de generated `app-view.html`. De `.eml`-bestanden zelf worden niet ge-render: ze zijn input, niet output.
