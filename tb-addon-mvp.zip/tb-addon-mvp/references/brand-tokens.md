# Track & Back brand-tokens

Bron: TB Brand Guideline Ver 02.2026 (Google Drive: TB Brand assests). Distilleer hieronder om de skill een herbruikbare basis te geven voor app-view CSS. De mockup-HTML inlijft deze tokens; er wordt nooit een extern CSS-bestand gerefereerd.

## Kleuren

### Primary (blauw)
| Token | Hex |
|---|---|
| primary/50 | `#EEF2F9` |
| primary/100 | `#D4E1F5` |
| primary/200 | `#A9C3EB` |
| primary/300 | `#7EA5E1` |
| primary/400 | `#4A7FCB` |
| primary/500 | `#2661B0` (kern) |
| primary/600 | `#0A3794` |
| primary/700 | `#082D78` |
| primary/800 | `#06235C` |
| primary/900 | `#041940` |

### Secondary (oranje, accent)
| Token | Hex |
|---|---|
| secondary/50 | `#FFF4E6` |
| secondary/100 | `#FFE4BD` |
| secondary/200 | `#FFCA7F` |
| secondary/300 | `#FFB347` |
| secondary/400 | `#FF9C23` |
| secondary/500 | `#FF8500` (kern accent) |
| secondary/600 | `#E67700` |
| secondary/700 | `#CC6900` |
| secondary/800 | `#B35C00` |
| secondary/900 | `#994E00` |

### Neutral (grijs)
| Token | Hex |
|---|---|
| neutral/50 | `#F8FAFC` (bg) |
| neutral/100 | `#F1F5F9` |
| neutral/200 | `#E2E8F0` (borders) |
| neutral/300 | `#CBD5E1` |
| neutral/400 | `#94A3B8` |
| neutral/500 | `#64748B` (muted tekst) |
| neutral/600 | `#475569` |
| neutral/700 | `#334155` |
| neutral/800 | `#1E293B` (tekst) |
| neutral/900 | `#0F172A` (zwaarste tekst) |

### Functional
| Token | Hex | Gebruik |
|---|---|---|
| error/500 | `#EF4444` | foutmelding |
| error/600 | `#DC2626` | foutmelding (hover) |
| success/500 | `#10B981` | bevestiging, klaar |
| success/600 | `#059669` | bevestiging (hover) |
| warning/500 | `#F59E0B` | waarschuwing, deadline |
| warning/600 | `#D97706` | waarschuwing (hover) |
| info/500 | `#3C82F6` | info |
| info/100 | `#DBEAFE` | info-achtergrond |

## Typografie

Inter via Google Fonts:
```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
```

Mobile UI stack:
| Rol | Stijl | Px |
|---|---|---|
| Display/H1 | Inter Bold | 28 |
| Display/H2 | Inter Bold | 24 |
| Display/H3 | Inter Bold | 20 |
| Body/Large | Inter Medium | 16 |
| Body/Regular | Inter Regular | 15 |
| Body/Medium | Inter Medium | 12 |
| Caption | Inter Regular | 12 |
| Label/Large | Inter Medium | 12 |
| Label/Small | Inter Medium | 10 |
| Button/Large | Inter SemiBold | 16 |
| Button/Medium | Inter Medium | 15 |

Section headers (kleine caps stijl, zoals in de Brand Guideline secties):
- Inter SemiBold 12pt, letter-spacing 0.14em, uppercase, kleur `neutral/500`

## Spacing (4px-grid)

| Token | Px |
|---|---|
| spacing/0 | 0 |
| spacing/1 | 4 |
| spacing/2 | 8 |
| spacing/3 | 12 |
| spacing/4 | 16 (basis) |
| spacing/5 | 20 |
| spacing/6 | 24 |
| spacing/8 | 32 |
| spacing/10 | 40 |
| spacing/12 | 48 |
| spacing/16 | 64 |
| spacing/20 | 80 |

## Border-radius

| Token | Px | Gebruik |
|---|---|---|
| radius/none | 0 | dividers |
| radius/sm | 4 | tags, inputs |
| radius/md | 8 | cards (default) |
| radius/lg | 12 | knoppen, bottom sheets |
| radius/xl | 16 | hero panels |
| radius/full | 999 | pills, avatars |

## Borders

- Default: `1px solid neutral/200`
- Focus/selected: `2px solid primary/500`

## Schaduwen

- shadow/xs: `0 1px 2px rgba(15, 23, 42, 0.04)`
- shadow/sm: `0 2px 4px rgba(15, 23, 42, 0.06)`
- shadow/md: `0 4px 12px rgba(15, 23, 42, 0.08)` (default voor primaire knop)
- shadow/lg: `0 12px 24px rgba(15, 23, 42, 0.10)`

## Componenten in de app-view

| Component | Tokens |
|---|---|
| App container | `max-width: 420px`, `margin: 0 auto`, `bg: neutral/50`, `padding: spacing/4` |
| Top app-bar | `bg: white`, `border-bottom: 1px solid neutral/200`, `padding: spacing/3 spacing/4` |
| Section header | section header stijl, `margin: spacing/6 0 spacing/3` |
| Card | `bg: white`, `border: 1px solid neutral/200`, `radius/md`, `padding: spacing/4`, `shadow/xs` |
| Pill | `bg: neutral/100`, `radius/full`, `padding: 4px 10px`, `font: Label/Small`, `color: neutral/600` |
| Primary CTA | `bg: secondary/500`, `color: white`, `radius/lg`, `padding: spacing/4`, `font: Button/Large`, `shadow/md` |
| Secondary CTA | `bg: primary/50`, `color: primary/600`, `radius/lg`, `padding: spacing/4`, `font: Button/Large` |
| Status-tag (success) | `bg: success/500` + 10% opacity, `color: success/600`, `radius/full` |
| Status-tag (warning) | `bg: warning/500` + 10% opacity, `color: warning/600`, `radius/full` |
| Footer afronding-tekst | `color: neutral/500`, `font: Caption`, `text-align: center`, `margin-top: spacing/8` |

## Tone-of-voice in tekst

- Geen em-dash in Nederlandse tekst, komma of dubbele punt gebruiken
- Rustig, helder, geen drukke werkwoorden, geen uitroeptekens
- Afronding-zin onderaan een scherm benoemt expliciet dat de gebruiker niets meer hoeft
- Geen "monitoring" of "controle" termen in UI-tekst, ook niet impliciet
